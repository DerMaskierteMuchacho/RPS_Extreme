# FS21

You will find the lecture material on this [website](https://dsl.hsr.ch/lect/fs21/)
