im entpackten directory DSq lb example: docker-compose up

erreichbar unter localhost:81 und localhost:82