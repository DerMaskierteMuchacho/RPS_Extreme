im entpackten directory DS1 LB example: docker-compose up

erreichbar unter localhost:81 und localhost:82